

/***************************** Include Files *******************************/
#include "iatcollector2chSmart.h"

/************************** Function Definitions ***************************/
